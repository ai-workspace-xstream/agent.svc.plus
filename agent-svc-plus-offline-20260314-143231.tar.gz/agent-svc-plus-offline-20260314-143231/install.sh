#!/bin/bash
# agent-svc-plus 离线安装脚本
set -e

INSTALL_DIR="/usr/local/bin"
CONFIG_DIR="/usr/local/etc/agent-svc-plus"
XRAY_DIR="/usr/local/etc/xray/templates"
LOG_DIR="/var/log/agent-svc-plus"
DATA_DIR="/var/lib/agent-svc-plus"
SERVICE_NAME="agent-svc-plus"

echo "=== agent-svc-plus 安装 ==="
echo "目标主机: $(hostname)"
echo ""

# 1. 创建目录
echo "[1/6] 创建目录..."
mkdir -p "$CONFIG_DIR" "$XRAY_DIR" "$LOG_DIR" "$DATA_DIR"

# 2. 安装二进制
echo "[2/6] 安装二进制文件..."
cp agent-svc-plus "$INSTALL_DIR/"
chmod 755 "$INSTALL_DIR/agent-svc-plus"

# 3. 复制配置模板
echo "[3/6] 复制配置模板..."
cp xray.xhttp.template.json "$XRAY_DIR/"
cp xray.tcp.template.json "$XRAY_DIR/"

# 4. 创建配置文件
echo "[4/6] 创建配置文件..."
cat > "$CONFIG_DIR/config.yaml" << EOF
mode: "agent"

log:
  level: info

agent:
  id: "us-xhttp.svc.plus"
  controllerUrl: "https://accounts-svc-plus-266500572462.asia-northeast1.run.app"
  apiToken: "${INTERNAL_SERVICE_TOKEN}"
  httpTimeout: 15s
  statusInterval: 1m
  syncInterval: 5m
  tls:
    insecureSkipVerify: false

xray:
  sync:
    enabled: true
    interval: 5m
    targets:
      - name: "xhttp"
        outputPath: "/usr/local/etc/xray/config.json"
        templatePath: "/usr/local/etc/xray/templates/xray.xhttp.template.json"
        validateCommand: []
        restartCommand: []
      - name: "tcp"
        outputPath: "/usr/local/etc/xray/tcp-config.json"
        templatePath: "/usr/local/etc/xray/templates/xray.tcp.template.json"
        validateCommand: []
        restartCommand: []
EOF
chmod 640 "$CONFIG_DIR/config.yaml"

# 5. 创建 systemd 服务
echo "[5/6] 创建 systemd 服务..."
cat > /etc/systemd/system/$SERVICE_NAME.service << 'EOF'
[Unit]
Description=Agent Svc Plus - us-xhttp.svc.plus
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/bin/agent-svc-plus --config /usr/local/etc/agent-svc-plus/config.yaml
WorkingDirectory=/var/lib/agent-svc-plus
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment=HOME=/root
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/usr/local/etc/agent-svc-plus /var/log/agent-svc-plus /usr/local/etc/xray

[Install]
WantedBy=multi-user.target
EOF

# 6. 启动服务
echo "[6/6] 启动服务..."
systemctl daemon-reload
systemctl enable $SERVICE_NAME
systemctl start $SERVICE_NAME

# 验证
echo ""
echo "=== 安装完成 ==="
sleep 2
systemctl status $SERVICE_NAME --no-pager || true

echo ""
echo "验证命令:"
echo "  systemctl status agent-svc-plus"
echo "  journalctl -u agent-svc-plus -f"
echo "  curl http://localhost:8080/healthz  # 如果有健康检查端口"
