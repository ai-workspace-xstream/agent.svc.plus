# agent-svc-plus 离线部署包

## 文件列表
- `agent-svc-plus` - 二进制文件 (11MB)
- `xray.xhttp.template.json` - XHTTP 模板
- `xray.tcp.template.json` - TCP 模板
- `install.sh` - 安装脚本
- `uninstall.sh` - 卸载脚本

## 部署方法

### 方法 1: 自动安装
```bash
# 传输到目标主机
scp -r agent-svc-plus-offline-* root@5.78.45.49:/tmp/

# SSH 登录并安装
ssh root@5.78.45.49
cd /tmp/agent-svc-plus-offline-*
sudo ./install.sh
```

### 方法 2: 手动安装
```bash
# 复制文件
sudo cp agent-svc-plus /usr/local/bin/
sudo chmod 755 /usr/local/bin/agent-svc-plus

# 创建目录
sudo mkdir -p /usr/local/etc/agent-svc-plus
sudo mkdir -p /usr/local/etc/xray/templates

# 复制配置
sudo cp xray.*.template.json /usr/local/etc/xray/templates/

# 创建配置文件 (编辑 config.yaml)
# 创建并启动 systemd 服务
```

## 验证
```bash
systemctl status agent-svc-plus
journalctl -u agent-svc-plus -f
```

## 卸载
```bash
sudo ./uninstall.sh
```
