#!/bin/bash
# agent-svc-plus 卸载脚本
set -e

echo "=== agent-svc-plus 卸载 ==="

# 停止并禁用服务
systemctl stop agent-svc-plus 2>/dev/null || true
systemctl disable agent-svc-plus 2>/dev/null || true

# 删除服务文件
rm -f /etc/systemd/system/agent-svc-plus.service
systemctl daemon-reload

# 删除文件
rm -f /usr/local/bin/agent-svc-plus
rm -rf /usr/local/etc/agent-svc-plus
rm -rf /var/log/agent-svc-plus
rm -rf /var/lib/agent-svc-plus

# 保留 xray 配置（可能有其他服务使用）
# rm -rf /usr/local/etc/xray

echo "✓ 卸载完成"
