# agent-svc-plus 部署包

## 文件列表
- `agent-svc-plus` - 二进制文件
- `xray.xhttp.template.json` - XHTTP 模板
- `xray.tcp.template.json` - TCP 模板
- `manual-deploy.sh` - 部署脚本
- `deploy.env` - 环境变量

## 部署方法

### 方法 1: 自动部署
```bash
source deploy.env
sudo ./manual-deploy.sh
```

## 验证
```bash
systemctl status agent-svc-plus
journalctl -u agent-svc-plus -f
```
