#!/bin/bash
# 手动部署脚本 - 在目标主机上执行
# 使用方法: ./manual-deploy.sh

set -e

# 配置
BINARY_NAME="agent-svc-plus"
INSTALL_DIR="/usr/local/bin"
CONFIG_DIR="/usr/local/etc/agent-svc-plus"
LOG_DIR="/var/log/agent-svc-plus"
XRAY_DIR="/usr/local/etc/xray/templates"

# 从环境变量或参数获取
AGENT_ID="${AGENT_ID:-us-xhttp.svc.plus}"
CONTROLLER_URL="${CONTROLLER_URL:-https://accounts-svc-plus-266500572462.asia-northeast1.run.app}"
API_TOKEN="${INTERNAL_SERVICE_TOKEN:-}"

echo "=== agent-svc-plus 部署 ==="
echo "目标主机: $(hostname)"
echo "Agent ID: $AGENT_ID"
echo ""

# 创建目录
echo "创建目录..."
mkdir -p "$CONFIG_DIR" "$LOG_DIR" "$XRAY_DIR"

# 复制二进制文件
echo "安装二进制文件..."
cp agent-svc-plus "$INSTALL_DIR/$BINARY_NAME"
chmod 755 "$INSTALL_DIR/$BINARY_NAME"

# 创建配置文件
echo "创建配置文件..."
cat > "$CONFIG_DIR/config.yaml" << EOF
mode: "agent"

log:
  level: info

agent:
  id: "$AGENT_ID"
  controllerUrl: "$CONTROLLER_URL"
  apiToken: "$API_TOKEN"
  httpTimeout: 15s
  statusInterval: 1m
  syncInterval: 5m
  tls:
    insecureSkipVerify: false

xray:
  sync:
    enabled: true
    interval: 5m
    targets:
      - name: "xhttp"
        outputPath: "/usr/local/etc/xray/config.json"
        templatePath: "/usr/local/etc/xray/templates/xray.xhttp.template.json"
        validateCommand: []
        restartCommand: []
      - name: "tcp"
        outputPath: "/usr/local/etc/xray/tcp-config.json"
        templatePath: "/usr/local/etc/xray/templates/xray.tcp.template.json"
        validateCommand: []
        restartCommand: []
EOF

# 创建 systemd 服务
echo "创建 systemd 服务..."
cat > /etc/systemd/system/$BINARY_NAME.service << 'EOF'
[Unit]
Description=Agent Svc Plus
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/bin/agent-svc-plus --config /usr/local/etc/agent-svc-plus/config.yaml
WorkingDirectory=/var/lib/agent-svc-plus
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# 启动服务
echo "启动服务..."
systemctl daemon-reload
systemctl enable $BINARY_NAME
systemctl start $BINARY_NAME

# 验证
echo ""
echo "=== 部署完成 ==="
systemctl status $BINARY_NAME --no-pager
echo ""
echo "日志命令: journalctl -u $BINARY_NAME -f"
